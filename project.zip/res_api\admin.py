from django.contrib import admin

from res_api import models


admin.site.register(models.UserProfile)
admin.site.register(models.ProfileFeedItem)
