from django.apps import AppConfig


class ResApiConfig(AppConfig):
    name = 'res_api'
